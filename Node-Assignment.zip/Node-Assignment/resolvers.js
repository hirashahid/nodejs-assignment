const data = require('./data.json')
const fs = require('fs');
const path = require('path');

const dataFilePath = path.join(__dirname, 'data.json');

const resolvers = {
  hello: () => {
    return 'Hello World!';
  },
  findUserById: (args) => {
    const { id } = args;
    return data.people.find(user => user.id === id);
  },
  people: ()=>{
    return data.people;
  },
  departments:()=>{
    return data.departments
  },
  findSpecificDepartmentById: (args) =>{
    const { id } = args;
    return data.departments.find(user => user.id === id);
  },
  userHierarchy: (args) => {
    const { id } = args;
    // Retrieve the user's information
    const user = data.people.find(user => user.id === id);
    if (!user) {
      throw new Error(`User with ID ${id} not found.`);
    }

    // Retrieve the user's department
    const department = data.departments.find(department => department.id === user.departmentId);

    // Retrieve the user's manager
    const manager = user.managerId ? data.people.find(manager => manager.id === user.managerId): null;
    // Return the user object with related data
    return {
      ...user,
      department,
      manager,
    };
  },
  updateUser: async (args) => {
        const { id, input } = args;
        // return data.people.findOneAndUpdate(
        //   {id: id}, 
        //   {
        //   firstName: input.firstName,
        //   lastName: input.lastName,
        //   jobTitle: input.jobTitle,
        //   departmentId: input.departmentId,
        // }, {
        //   new: true
        // });
        const user = data.people.find(user => user.id === id);

        // If the user doesn't exist, throw an error
        if (!user) {
          throw new Error(`User with ID ${id} not found.`);
        }
        
        // Update the user fields based on the input
        input.firstName ? user.firstName = input.firstName : user.firstName = user.firstName;
        input.lastName ? user.lastName = input.lastName : user.lastName = user.lastName;
        input.jobTitle ? user.jobTitle = input.jobTitle : user.jobTitle = user.jobTitle;
        input.departmentId ? user.departmentId = input.departmentId : user.departmentId = user.departmentId;
        (input.managerId && user.managerId) ? user.managerId = input.managerId : user.managerId = user.managerId;
        // if (input.firstName) {
        //   user.firstName = input.firstName;
        // }
        // if (input.lastName) {
        //   user.lastName = input.lastName;
        // }
        // if (input.jobTitle) {
        //   user.jobTitle = input.jobTitle;
        // }
        // if (input.departmentId) {
        //   user.departmentId = input.departmentId;
        // }
        // if(user.managerId && input.managerId) {
        //   user.managerId = input.managerId;
        // }
        
        // Save the updated user to the database
        // await user.save();
        
        // Return the updated user object
        return user
      }
    
};

module.exports = resolvers;