const { buildSchema } = require('graphql');

const schema = buildSchema(`
type Department {
  id: String!
  name: String!
}
type Person {
  id: String!
  firstName: String!
  lastName: String!
  jobTitle: String!
  department: Department!
  manager: Person
}
input UserInput {
  firstName: String
  lastName: String
  jobTitle: String
  departmentId: String
  managerId: String
}
type Query {
  departments: [Department!]!
  people: [Person!]!
  findUserById(id:ID):Person
  findSpecificDepartmentById(id:ID):Department
  userHierarchy(id:ID):Person
}
type Mutation {
  updateUser(id: ID!, input: UserInput!): Person!
}
schema {
  query: Query
  mutation: Mutation
}
`);

module.exports = schema;
